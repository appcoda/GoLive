//
//  ViewController.swift
//  GoLiveStarter
//
//  Created by Mitchell Sweet on 8/18/17.
//  Copyright © 2017 Mitchell Sweet. All rights reserved.
//

import UIKit
import ReplayKit

// There will be an error here which be resolved once delegate functions are added.
class ViewController: UIViewController, RPBroadcastActivityViewControllerDelegate {
    
    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var colorSelector: UISegmentedControl!
    @IBOutlet var colorView: UIView!
    @IBOutlet var broadcastButton: UIButton!
    @IBOutlet var micSwitch: UISwitch!
    @IBOutlet var micLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        statusLabel.text = "You are not live"
    }
    
    @IBAction func didPressBroadcastButton() {
        // Called when broadcast button is tapped. Runs functions to start or stop broadcast.
        
    }
    
    func startBroadcast() {
        
        
    }
    
    func stopBroadcast() {
        
        
    }
    
    
    func broadcastStarted() {
        // Called to update the UI when a broadcast starts.
        
    }
    
    func broadcastEnded() {
        // Called to update the UI when a broadcast ends.
        
    }
    
    
    @IBAction func enableMic(sender: UISwitch) {
        // Called when microphone switch is toggled.
        
        if sender.isOn {
            // Enable Microphone
            
        }
        else {
            // Disable Microphone
            
        }
        
    }

    
    
    // Function for handling the changing of the colored square.
    // This function does not need to be edited for tutorial. 
    @IBAction func colorSelector(sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            colorView.backgroundColor = UIColor.red
        case 1:
            colorView.backgroundColor = UIColor.blue
        case 2:
            colorView.backgroundColor = UIColor.orange
        case 3:
            colorView.backgroundColor = UIColor.green
        default:
            colorView.backgroundColor = UIColor.red
        }

    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        print("Memory warning triggered. If running this app on an older device, you might want to remove some apps from multitasking.")
    }


}

